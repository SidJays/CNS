module.exports = {
    entry: "./jsCode.js",
    output: {
        path: __dirname,
        filename: "bundle.js"
    },
    module: {
   rules: [
        use: [
         {
           loader: "style-loader"
         },
         {
           loader: "css-loader",
           options: {
             modules: true
           },
         }
	]
	]
	}
};